# My VoIP

Android SIP/VoIP app (Kotlin + Jetpack Compose, Linphone SDK).

## Features

| Area | What's included |
|---|---|
| Calling | SIP login/logout, dial pad, incoming/outgoing calls, mute, speaker, hold, call timer |
| Contacts | Phone contacts + app's own contacts, search, add, edit, delete, favorites, tap to call |
| Call management | Incoming/outgoing/missed history, call details, call recording (with consent prompt) |
| Backup | Manual backup, restore, daily automatic backup (Google Drive upload: see below) |
| Settings | SIP server, audio, notifications, privacy |

## Build from your phone (no computer needed)

1. Create a new GitHub repository and upload this whole folder (GitHub app or github.com in the browser).
2. Open the **Actions** tab → **Build APK** → **Run workflow** (it also runs on every push to `main`).
3. When it finishes, open the run and download the **MyVoIP-apk** artifact. Install the `arm64-v8a` APK on most modern phones.

The build log prints each APK's size and warns if one exceeds 20 MB.

## Keeping the APK under 20 MB

- One APK per CPU type (`arm64-v8a`, `armeabi-v7a`) instead of one big universal APK.
- Audio-only SIP SDK (`org.linphone.no-video`). If still too big, set `LINPHONE_GROUP=org.linphone.minimal` in `gradle.properties`.
- R8 code shrinking and resource shrinking are on for release builds.

## Known gaps / next steps

- **Not compiled yet.** This project was written without being able to run a build; expect to fix a few compile errors on the first GitHub Actions run (paste the log and they can be fixed quickly).
- **Linphone version**: `gradle.properties` uses `5.3+`. Pin an exact version once the first build works.
- **Google Drive backup**: backup/restore works on a local file. Uploading to Drive needs a Google Cloud OAuth client (Android type, with this app's package name and signing SHA-1); `DriveUploader` is the stub to fill in.
- **Incoming calls when the app is closed** need a SIP push gateway (or the foreground service kept running). Currently the app only receives calls while it is running/registered.
- **Release signing**: the release build uses the debug key so it installs. Add your own keystore via GitHub Secrets before publishing.
- **Call recording**: only starts after the user confirms the other party agreed; rules differ by country.
