pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven {
            name = "linphone.org maven repository"
            url = uri("https://linphone.org/maven_repository/")
            content { includeGroupByRegex("org\\.linphone.*") }
        }
    }
}

rootProject.name = "MyVoIP"
include(":app")
