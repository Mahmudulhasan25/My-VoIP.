# Linphone uses JNI and reflection; keep its classes.
-keep class org.linphone.** { *; }
-dontwarn org.linphone.**
