# Linphone uses JNI and reflection; keep its classes.
-keep class org.linphone.** { *; }
-dontwarn org.linphone.**

# Tink (used by androidx.security:security-crypto) references annotation-only classes
# that are not shipped at runtime.
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
-dontwarn javax.annotation.concurrent.**
-dontwarn com.google.crypto.tink.**
