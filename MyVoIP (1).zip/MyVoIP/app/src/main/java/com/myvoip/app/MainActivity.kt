package com.myvoip.app

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.myvoip.app.ui.*
import com.myvoip.app.sip.SipManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Root() } }
    }
}

private val tabs = listOf("📞 Dial", "👤 Contacts", "🕘 History", "⚙ Settings")

@Composable
private fun Root() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var dialNumber by remember { mutableStateOf("") }
    val call by SipManager.call.collectAsState()

    // Ask for the permissions the features need (each feature degrades gracefully if refused).
    val askPermissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) {
        askPermissions.launch(arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.POST_NOTIFICATIONS,
            Manifest.permission.BLUETOOTH_CONNECT,
        ))
    }

    if (call != null) { InCallScreen(call!!); return }

    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEachIndexed { i, label ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                    icon = { Text(label.substringBefore(' ')) },
                    label = { Text(label.substringAfter(' ')) })
            }
        }
    }) { pad ->
        val m = Modifier.padding(pad)
        when (tab) {
            0 -> DialerScreen(m, dialNumber, { dialNumber = it })
            1 -> ContactsScreen(m, onCall = { SipManager.dial(it) })
            2 -> HistoryScreen(m, onCall = { dialNumber = it; tab = 0 })
            else -> SettingsScreen(m)
        }
    }
}
