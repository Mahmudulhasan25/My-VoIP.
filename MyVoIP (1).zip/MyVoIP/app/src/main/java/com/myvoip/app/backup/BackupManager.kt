package com.myvoip.app.backup

import android.content.Context
import androidx.work.*
import com.myvoip.app.data.*
import com.myvoip.app.settings.Prefs
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Backup = one JSON file holding app contacts, call history and non-secret settings.
 * The SIP password is NOT backed up.
 *
 * Step 1 (done here): create / restore the backup file locally, run daily via WorkManager.
 * Step 2 (TODO): upload that file to Google Drive (appDataFolder) — see [DriveUploader].
 */
object BackupManager {

    private const val DAILY_WORK = "daily_backup"

    fun backupFile(ctx: Context) = File(ctx.filesDir, "myvoip_backup.json")

    suspend fun createBackup(ctx: Context): File {
        val db = AppDb.get(ctx)
        val prefs = Prefs(ctx)
        val json = JSONObject().apply {
            put("version", 1)
            put("createdAt", System.currentTimeMillis())
            put("contacts", JSONArray().apply {
                db.contacts().getAll().forEach {
                    put(JSONObject().put("name", it.name).put("number", it.number).put("favorite", it.favorite))
                }
            })
            put("calls", JSONArray().apply {
                db.callLog().getAll().forEach {
                    put(JSONObject().put("number", it.number).put("dir", it.direction.name)
                        .put("startedAt", it.startedAt).put("durationSec", it.durationSec))
                }
            })
            put("settings", JSONObject()
                .put("sipUser", prefs.sipUser).put("sipDomain", prefs.sipDomain)
                .put("sipTransport", prefs.sipTransport).put("echoCancellation", prefs.echoCancellation)
                .put("defaultSpeaker", prefs.defaultSpeaker))
        }
        val file = backupFile(ctx)
        file.writeText(json.toString())
        prefs.lastBackupMs = System.currentTimeMillis()
        DriveUploader.upload(ctx, file)
        return file
    }

    /** Replaces current contacts/history/settings with the backup's contents. */
    suspend fun restore(ctx: Context, file: File = backupFile(ctx)): Boolean {
        if (!file.exists()) return false
        val json = JSONObject(file.readText())
        val db = AppDb.get(ctx)
        db.contacts().clear()
        db.contacts().insertAll(json.getJSONArray("contacts").let { a ->
            (0 until a.length()).map { a.getJSONObject(it).let { o ->
                AppContact(name = o.getString("name"), number = o.getString("number"), favorite = o.optBoolean("favorite")) } }
        })
        db.callLog().clear()
        db.callLog().insertAll(json.getJSONArray("calls").let { a ->
            (0 until a.length()).map { a.getJSONObject(it).let { o ->
                CallLogEntry(number = o.getString("number"), direction = Direction.valueOf(o.getString("dir")),
                    startedAt = o.getLong("startedAt"), durationSec = o.getInt("durationSec")) } }
        })
        json.optJSONObject("settings")?.let { s ->
            Prefs(ctx).apply {
                sipUser = s.optString("sipUser"); sipDomain = s.optString("sipDomain")
                sipTransport = s.optString("sipTransport", "UDP")
                echoCancellation = s.optBoolean("echoCancellation", true)
                defaultSpeaker = s.optBoolean("defaultSpeaker")
            }
        }
        return true
    }

    fun setDailyBackup(ctx: Context, enabled: Boolean) {
        Prefs(ctx).dailyBackup = enabled
        val wm = WorkManager.getInstance(ctx)
        if (!enabled) { wm.cancelUniqueWork(DAILY_WORK); return }
        val req = PeriodicWorkRequestBuilder<DailyBackupWorker>(1, TimeUnit.DAYS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.UNMETERED).build())
            .build()
        wm.enqueueUniquePeriodicWork(DAILY_WORK, ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}

class DailyBackupWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = try {
        BackupManager.createBackup(applicationContext); Result.success()
    } catch (e: Exception) { Result.retry() }
}

/**
 * Google Drive upload — NOT implemented yet. Needs a Google Cloud OAuth client
 * (Android type, with this app's package name + signing SHA-1). Once you have that,
 * this will sign in with Google, request the drive.appdata scope, and upload the file
 * through the Drive REST API into the hidden app-data folder.
 */
object DriveUploader {
    @Suppress("UNUSED_PARAMETER")
    suspend fun upload(ctx: Context, file: File) { /* TODO */ }
}
