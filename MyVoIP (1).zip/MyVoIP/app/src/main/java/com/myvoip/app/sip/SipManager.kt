package com.myvoip.app.sip

import android.content.Context
import com.myvoip.app.data.AppDb
import com.myvoip.app.data.CallLogEntry
import com.myvoip.app.data.Direction
import com.myvoip.app.settings.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.linphone.core.*
import java.io.File

data class CallUi(
    val number: String,
    val state: String,
    val incoming: Boolean,
    val established: Boolean = false,
    val muted: Boolean = false,
    val speaker: Boolean = false,
    val held: Boolean = false,
    val recording: Boolean = false,
    val connectedAtMs: Long = 0L,
)

/** Wraps the Linphone core: SIP login/logout, calls, mute/speaker/hold, recording. */
object SipManager {
    private lateinit var core: Core
    private lateinit var appContext: Context
    private lateinit var prefs: Prefs
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _registration = MutableStateFlow("Logged out")
    val registration: StateFlow<String> = _registration

    private val _call = MutableStateFlow<CallUi?>(null)
    val call: StateFlow<CallUi?> = _call

    private val listener = object : CoreListenerStub() {
        override fun onAccountRegistrationStateChanged(core: Core, account: Account, state: RegistrationState, message: String) {
            _registration.value = when (state) {
                RegistrationState.Ok -> "Logged in"
                RegistrationState.Progress -> "Connecting…"
                RegistrationState.Failed -> "Login failed: $message"
                else -> "Logged out"
            }
        }

        override fun onCallStateChanged(core: Core, call: Call, state: Call.State, message: String) {
            val number = call.remoteAddress.asStringUriOnly().removePrefix("sip:").substringBefore('@')
            when (state) {
                Call.State.IncomingReceived ->
                    _call.value = CallUi(number, "Incoming call", incoming = true)
                Call.State.OutgoingInit, Call.State.OutgoingProgress, Call.State.OutgoingRinging ->
                    _call.value = CallUi(number, "Calling…", incoming = false)
                Call.State.StreamsRunning ->
                    _call.value = (_call.value ?: CallUi(number, "", call.dir == Call.Dir.Incoming)).copy(
                        state = "Connected", established = true, held = false,
                        connectedAtMs = _call.value?.connectedAtMs?.takeIf { it > 0 } ?: System.currentTimeMillis(),
                    )
                Call.State.Pausing, Call.State.Paused ->
                    _call.value = _call.value?.copy(state = "On hold", held = true)
                Call.State.End, Call.State.Error, Call.State.Released -> {
                    if (state != Call.State.Released) logCall(call, number)
                    if (core.callsNb == 0) _call.value = null
                }
                else -> Unit
            }
        }
    }

    fun init(context: Context) {
        appContext = context.applicationContext
        prefs = Prefs(appContext)
        core = Factory.instance().createCore(null, null, appContext)
        core.addListener(listener)
        core.isEchoCancellationEnabled = prefs.echoCancellation
        core.start()
        if (prefs.autoLogin && prefs.sipUser.isNotBlank()) login()
    }

    // ---- Login / logout -------------------------------------------------

    fun login(
        user: String = prefs.sipUser,
        password: String = prefs.sipPassword,
        domain: String = prefs.sipDomain,
        transport: String = prefs.sipTransport,
    ) {
        logout()
        val factory = Factory.instance()
        core.addAuthInfo(factory.createAuthInfo(user, null, password, null, null, domain))
        val params = core.createAccountParams()
        params.identityAddress = factory.createAddress("sip:$user@$domain")
        val server = factory.createAddress("sip:$domain")
        server?.transport = when (transport.uppercase()) {
            "TCP" -> TransportType.Tcp
            "TLS" -> TransportType.Tls
            else -> TransportType.Udp
        }
        params.serverAddress = server
        params.isRegisterEnabled = true
        val account = core.createAccount(params)
        core.addAccount(account)
        core.defaultAccount = account
    }

    fun logout() {
        core.defaultAccount?.let { acc ->
            val p = acc.params.clone()
            p.isRegisterEnabled = false
            acc.params = p
        }
        core.clearAccounts()
        core.clearAllAuthInfo()
        _registration.value = "Logged out"
    }

    // ---- Calls ----------------------------------------------------------

    fun dial(number: String) {
        if (number.isBlank()) return
        val addr = core.interpretUrl(number, true) ?: return
        core.inviteAddress(addr)
    }

    fun answer() { core.currentCall?.accept() }
    fun hangUp() { (core.currentCall ?: core.calls.firstOrNull())?.terminate() }

    fun toggleMute() {
        core.isMicEnabled = !core.isMicEnabled
        _call.value = _call.value?.copy(muted = !core.isMicEnabled)
    }

    fun toggleSpeaker() {
        val wantSpeaker = _call.value?.speaker != true
        val type = if (wantSpeaker) AudioDevice.Type.Speaker else AudioDevice.Type.Earpiece
        core.audioDevices.firstOrNull { it.type == type }?.let { core.outputAudioDevice = it }
        _call.value = _call.value?.copy(speaker = wantSpeaker)
    }

    fun toggleHold() {
        val c = core.currentCall ?: return
        if (c.state == Call.State.Paused) c.resume() else c.pause()
    }

    /**
     * Recording. The UI must confirm consent first (see Prefs.recordingConsentPrompt);
     * recording calls without the other party's agreement is illegal in many places.
     */
    fun toggleRecording() {
        val c = core.currentCall ?: return
        val ui = _call.value ?: return
        if (ui.recording) {
            c.stopRecording()
        } else {
            val dir = File(appContext.getExternalFilesDir(null), "recordings").apply { mkdirs() }
            val params = core.createCallParams(c) ?: return
            params.recordFile = File(dir, "call_${System.currentTimeMillis()}.wav").absolutePath
            c.update(params)
            c.startRecording()
        }
        _call.value = ui.copy(recording = !ui.recording)
    }

    // ---- Call history ---------------------------------------------------

    private fun logCall(call: Call, number: String) {
        val missed = call.callLog.status == Call.Status.Missed
        val dir = when {
            missed -> Direction.MISSED
            call.dir == Call.Dir.Incoming -> Direction.INCOMING
            else -> Direction.OUTGOING
        }
        val entry = CallLogEntry(
            number = number,
            direction = dir,
            startedAt = call.callLog.startDate * 1000,
            durationSec = call.duration,
            recordingPath = call.params.recordFile?.takeIf { File(it).exists() },
        )
        scope.launch { AppDb.get(appContext).callLog().insert(entry) }
    }
}
