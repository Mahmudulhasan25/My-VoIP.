package com.myvoip.app.contacts

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone

data class PhoneContact(val lookupKey: String, val name: String, val number: String)

/** Reads, edits and deletes contacts stored on the phone (needs READ/WRITE_CONTACTS). */
object PhoneContacts {

    fun load(ctx: Context): List<PhoneContact> {
        val out = mutableListOf<PhoneContact>()
        ctx.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.LOOKUP_KEY, Phone.DISPLAY_NAME, Phone.NUMBER),
            null, null, "${Phone.DISPLAY_NAME} COLLATE NOCASE ASC",
        )?.use { c ->
            while (c.moveToNext()) {
                out += PhoneContact(c.getString(0) ?: continue, c.getString(1) ?: "", c.getString(2) ?: "")
            }
        }
        return out.distinctBy { it.lookupKey + it.number }
    }

    /** Name / number search, done in memory on the already-loaded list. */
    fun search(all: List<PhoneContact>, query: String): List<PhoneContact> {
        val q = query.trim()
        if (q.isEmpty()) return all
        val digits = q.filter { it.isDigit() }
        return all.filter {
            it.name.contains(q, ignoreCase = true) ||
                (digits.isNotEmpty() && it.number.filter { ch -> ch.isDigit() }.contains(digits))
        }
    }

    /** Opens the system contact editor. */
    fun editIntent(ctx: Context, c: PhoneContact): Intent {
        val uri = ContactsContract.Contacts.lookupContact(ctx.contentResolver,
            ContactsContract.Contacts.getLookupUri(0, c.lookupKey))
        return Intent(Intent.ACTION_EDIT).setDataAndType(uri, ContactsContract.Contacts.CONTENT_ITEM_TYPE)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** Opens the system "new contact" screen with the number pre-filled. */
    fun insertIntent(name: String, number: String): Intent =
        Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
            putExtra(ContactsContract.Intents.Insert.NAME, name)
            putExtra(ContactsContract.Intents.Insert.PHONE, number)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

    fun delete(resolver: ContentResolver, c: PhoneContact): Boolean {
        val uri: Uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_LOOKUP_URI, c.lookupKey)
        return resolver.delete(uri, null, null) > 0
    }
}
