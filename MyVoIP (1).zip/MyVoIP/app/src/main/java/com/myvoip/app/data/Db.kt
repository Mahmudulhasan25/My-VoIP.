package com.myvoip.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "app_contacts")
data class AppContact(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val number: String,
    val favorite: Boolean = false,
)

enum class Direction { INCOMING, OUTGOING, MISSED }

@Entity(tableName = "call_log")
data class CallLogEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String,
    val direction: Direction,
    val startedAt: Long,
    val durationSec: Int,
    val recordingPath: String? = null,
)

@Dao
interface ContactDao {
    @Query("SELECT * FROM app_contacts ORDER BY favorite DESC, name COLLATE NOCASE")
    fun observeAll(): Flow<List<AppContact>>

    @Query("SELECT * FROM app_contacts") suspend fun getAll(): List<AppContact>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(c: AppContact)
    @Insert suspend fun insertAll(list: List<AppContact>)
    @Delete suspend fun delete(c: AppContact)
    @Query("DELETE FROM app_contacts") suspend fun clear()
}

@Dao
interface CallLogDao {
    @Query("SELECT * FROM call_log ORDER BY startedAt DESC")
    fun observeAll(): Flow<List<CallLogEntry>>

    @Query("SELECT * FROM call_log") suspend fun getAll(): List<CallLogEntry>
    @Insert suspend fun insert(e: CallLogEntry)
    @Insert suspend fun insertAll(list: List<CallLogEntry>)
    @Delete suspend fun delete(e: CallLogEntry)
    @Query("DELETE FROM call_log") suspend fun clear()
}

class Converters {
    @TypeConverter fun fromDir(d: Direction): String = d.name
    @TypeConverter fun toDir(s: String): Direction = Direction.valueOf(s)
}

@Database(entities = [AppContact::class, CallLogEntry::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDb : RoomDatabase() {
    abstract fun contacts(): ContactDao
    abstract fun callLog(): CallLogDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(ctx: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "myvoip.db")
                .build().also { instance = it }
        }
    }
}
