package com.myvoip.app.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myvoip.app.backup.BackupManager
import com.myvoip.app.contacts.PhoneContact
import com.myvoip.app.contacts.PhoneContacts
import com.myvoip.app.data.*
import com.myvoip.app.settings.Prefs
import com.myvoip.app.sip.CallUi
import com.myvoip.app.sip.SipManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

// ───────────────────────── Dial pad ─────────────────────────

@Composable
fun DialerScreen(modifier: Modifier, number: String, onNumber: (String) -> Unit) {
    val reg by SipManager.registration.collectAsState()
    val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#")
    Column(modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(reg, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(16.dp))
        Text(number.ifEmpty { " " }, fontSize = 32.sp)
        Spacer(Modifier.height(16.dp))
        keys.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { k -> OutlinedButton(onClick = { onNumber(number + k) }, Modifier.padding(4.dp).weight(1f)) { Text(k, fontSize = 22.sp) } }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { SipManager.dial(number) }, enabled = number.isNotEmpty()) { Text("Call") }
            OutlinedButton(onClick = { onNumber(number.dropLast(1)) }) { Text("⌫") }
        }
    }
}

// ───────────────────────── In-call ─────────────────────────

@Composable
fun InCallScreen(call: CallUi) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var seconds by remember { mutableIntStateOf(0) }
    var askConsent by remember { mutableStateOf(false) }

    LaunchedEffect(call.connectedAtMs) {
        while (call.connectedAtMs > 0) {
            seconds = ((System.currentTimeMillis() - call.connectedAtMs) / 1000).toInt()
            delay(500)
        }
    }

    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(call.number, fontSize = 28.sp)
        Text(call.state)
        if (call.established) Text("%02d:%02d".format(seconds / 60, seconds % 60), fontSize = 20.sp)
        Spacer(Modifier.height(32.dp))

        if (call.incoming && !call.established) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(onClick = { SipManager.answer() }) { Text("Answer") }
                Button(onClick = { SipManager.hangUp() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Decline") }
            }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(call.muted, { SipManager.toggleMute() }, { Text("Mute") })
                FilterChip(call.speaker, { SipManager.toggleSpeaker() }, { Text("Speaker") })
                FilterChip(call.held, { SipManager.toggleHold() }, { Text("Hold") })
                FilterChip(call.recording, {
                    if (!call.recording && prefs.recordingConsentPrompt) askConsent = true else SipManager.toggleRecording()
                }, { Text("Rec") })
            }
            Spacer(Modifier.height(24.dp))
            Button(onClick = { SipManager.hangUp() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("End call") }
        }
    }

    if (askConsent) AlertDialog(
        onDismissRequest = { askConsent = false },
        title = { Text("Record this call?") },
        text = { Text("Recording is only allowed if the other person has agreed, and the rules differ by country. Have they agreed?") },
        confirmButton = { TextButton({ askConsent = false; SipManager.toggleRecording() }) { Text("Yes, start recording") } },
        dismissButton = { TextButton({ askConsent = false }) { Text("Cancel") } },
    )
}

// ───────────────────────── Contacts ─────────────────────────

@Composable
fun ContactsScreen(modifier: Modifier, onCall: (String) -> Unit) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).contacts() }
    val appContacts by dao.observeAll().collectAsState(emptyList())
    var phone by remember { mutableStateOf<List<PhoneContact>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var favoritesOnly by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) { phone = runCatching { PhoneContacts.load(ctx) }.getOrDefault(emptyList()) }

    val q = query.trim()
    val appShown = appContacts.filter {
        (!favoritesOnly || it.favorite) && (q.isEmpty() || it.name.contains(q, true) || it.number.contains(q))
    }
    val phoneShown = if (favoritesOnly) emptyList() else PhoneContacts.search(phone, q)

    Column(modifier.fillMaxSize()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, Modifier.weight(1f), label = { Text("Search name or number") }, singleLine = true)
            Spacer(Modifier.width(8.dp))
            FilterChip(favoritesOnly, { favoritesOnly = !favoritesOnly }, { Text("★") })
            Spacer(Modifier.width(4.dp))
            Button(onClick = { showAdd = true }) { Text("+") }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            if (appShown.isNotEmpty()) item { Text("App contacts", Modifier.padding(12.dp), style = MaterialTheme.typography.titleSmall) }
            items(appShown, key = { "a${it.id}" }) { c ->
                ListItem(
                    headlineContent = { Text(c.name) }, supportingContent = { Text(c.number) },
                    trailingContent = {
                        Row {
                            TextButton({ scope.launch { dao.upsert(c.copy(favorite = !c.favorite)) } }) { Text(if (c.favorite) "★" else "☆") }
                            TextButton({ scope.launch { dao.delete(c) } }) { Text("🗑") }
                        }
                    },
                    modifier = Modifier.clickable { onCall(c.number) },
                )
            }
            if (phoneShown.isNotEmpty()) item { Text("Phone contacts", Modifier.padding(12.dp), style = MaterialTheme.typography.titleSmall) }
            items(phoneShown, key = { "p${it.lookupKey}${it.number}" }) { c ->
                ListItem(
                    headlineContent = { Text(c.name) }, supportingContent = { Text(c.number) },
                    trailingContent = {
                        Row {
                            TextButton({ ctx.startActivity(PhoneContacts.editIntent(ctx, c)) }) { Text("✎") }
                            TextButton({
                                if (PhoneContacts.delete(ctx.contentResolver, c)) phone = phone - c else toast(ctx, "Could not delete")
                            }) { Text("🗑") }
                        }
                    },
                    modifier = Modifier.clickable { onCall(c.number) },
                )
            }
        }
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var number by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("New contact") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                    OutlinedTextField(number, { number = it }, label = { Text("Number") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                }
            },
            confirmButton = {
                TextButton({
                    if (name.isNotBlank() && number.isNotBlank()) scope.launch { dao.upsert(AppContact(name = name.trim(), number = number.trim())) }
                    showAdd = false
                }) { Text("Save in app") }
            },
            dismissButton = {
                TextButton({ ctx.startActivity(PhoneContacts.insertIntent(name, number)); showAdd = false }) { Text("Save on phone") }
            },
        )
    }
}

// ───────────────────────── History ─────────────────────────

@Composable
fun HistoryScreen(modifier: Modifier, onCall: (String) -> Unit) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).callLog() }
    val all by dao.observeAll().collectAsState(emptyList())
    var filter by remember { mutableStateOf<Direction?>(null) }
    var selected by remember { mutableStateOf<CallLogEntry?>(null) }
    val scope = rememberCoroutineScope()
    val shown = all.filter { filter == null || it.direction == filter }
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }

    Column(modifier.fillMaxSize()) {
        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(filter == null, { filter = null }, { Text("All") })
            FilterChip(filter == Direction.INCOMING, { filter = Direction.INCOMING }, { Text("Incoming") })
            FilterChip(filter == Direction.OUTGOING, { filter = Direction.OUTGOING }, { Text("Outgoing") })
            FilterChip(filter == Direction.MISSED, { filter = Direction.MISSED }, { Text("Missed") })
        }
        LazyColumn {
            items(shown, key = { it.id }) { e ->
                ListItem(
                    headlineContent = { Text(e.number) },
                    supportingContent = { Text("${e.direction.name.lowercase()} · ${fmt.format(Date(e.startedAt))}") },
                    modifier = Modifier.clickable { selected = e },
                )
            }
        }
    }

    selected?.let { e ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(e.number) },
            text = {
                Text("Type: ${e.direction.name.lowercase()}\nTime: ${fmt.format(Date(e.startedAt))}\n" +
                    "Duration: ${e.durationSec / 60}m ${e.durationSec % 60}s\n" +
                    (e.recordingPath?.let { "Recording: $it" } ?: "No recording"))
            },
            confirmButton = { TextButton({ onCall(e.number); selected = null }) { Text("Call back") } },
            dismissButton = { TextButton({ scope.launch { dao.delete(e) }; selected = null }) { Text("Delete") } },
        )
    }
}

// ───────────────────────── Settings & backup ─────────────────────────

@Composable
fun SettingsScreen(modifier: Modifier) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val reg by SipManager.registration.collectAsState()
    val scope = rememberCoroutineScope()

    var user by remember { mutableStateOf(prefs.sipUser) }
    var pass by remember { mutableStateOf(prefs.sipPassword) }
    var domain by remember { mutableStateOf(prefs.sipDomain) }
    var transport by remember { mutableStateOf(prefs.sipTransport) }
    var autoLogin by remember { mutableStateOf(prefs.autoLogin) }
    var echo by remember { mutableStateOf(prefs.echoCancellation) }
    var notifyIn by remember { mutableStateOf(prefs.notifyIncoming) }
    var notifyMissed by remember { mutableStateOf(prefs.notifyMissed) }
    var recConsent by remember { mutableStateOf(prefs.recordingConsentPrompt) }
    var daily by remember { mutableStateOf(prefs.dailyBackup) }

    @Composable
    fun Switch(label: String, value: Boolean, on: (Boolean) -> Unit) =
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label); androidx.compose.material3.Switch(value, on)
        }

    Column(modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("SIP server", style = MaterialTheme.typography.titleMedium)
        Text(reg)
        OutlinedTextField(user, { user = it }, Modifier.fillMaxWidth(), label = { Text("Username") }, singleLine = true)
        OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
        OutlinedTextField(domain, { domain = it }, Modifier.fillMaxWidth(), label = { Text("Server / domain") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("UDP", "TCP", "TLS").forEach { t -> FilterChip(transport == t, { transport = t }, { Text(t) }) }
        }
        Switch("Log in automatically", autoLogin) { autoLogin = it; prefs.autoLogin = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({
                prefs.sipUser = user; prefs.sipPassword = pass; prefs.sipDomain = domain; prefs.sipTransport = transport
                SipManager.login(user, pass, domain, transport)
            }) { Text("Login") }
            OutlinedButton({ SipManager.logout() }) { Text("Logout") }
        }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("Audio", style = MaterialTheme.typography.titleMedium)
        Switch("Echo cancellation", echo) { echo = it; prefs.echoCancellation = it }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("Notifications", style = MaterialTheme.typography.titleMedium)
        Switch("Incoming calls", notifyIn) { notifyIn = it; prefs.notifyIncoming = it }
        Switch("Missed calls", notifyMissed) { notifyMissed = it; prefs.notifyMissed = it }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("Privacy & security", style = MaterialTheme.typography.titleMedium)
        Switch("Ask for consent before recording", recConsent) { recConsent = it; prefs.recordingConsentPrompt = it }
        Text("Your SIP password is stored encrypted on this phone and is never included in backups.", style = MaterialTheme.typography.bodySmall)

        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        Text("Backup", style = MaterialTheme.typography.titleMedium)
        Switch("Daily automatic backup", daily) { daily = it; BackupManager.setDailyBackup(ctx, it) }
        Text(if (prefs.lastBackupMs == 0L) "No backup yet" else "Last backup: ${Date(prefs.lastBackupMs)}", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ scope.launch { runCatching { BackupManager.createBackup(ctx) }.onSuccess { toast(ctx, "Backup saved") }.onFailure { toast(ctx, "Backup failed") } } }) { Text("Back up now") }
            OutlinedButton({ scope.launch { toast(ctx, if (BackupManager.restore(ctx)) "Restored" else "No backup found") } }) { Text("Restore") }
        }
        Text("Google Drive upload is not connected yet (see README).", style = MaterialTheme.typography.bodySmall)
    }
}
