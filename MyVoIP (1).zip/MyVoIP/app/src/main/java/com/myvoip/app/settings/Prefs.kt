package com.myvoip.app.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** App settings. The SIP password is stored encrypted and is never included in backups. */
class Prefs(ctx: Context) {
    private val plain: SharedPreferences = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val secure: SharedPreferences = EncryptedSharedPreferences.create(
        ctx, "secure", MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    // SIP server settings
    var sipUser: String get() = plain.getString("sipUser", "") ?: ""; set(v) = plain.edit().putString("sipUser", v).apply()
    var sipDomain: String get() = plain.getString("sipDomain", "") ?: ""; set(v) = plain.edit().putString("sipDomain", v).apply()
    var sipTransport: String get() = plain.getString("sipTransport", "UDP") ?: "UDP"; set(v) = plain.edit().putString("sipTransport", v).apply()
    var sipPassword: String get() = secure.getString("sipPassword", "") ?: ""; set(v) = secure.edit().putString("sipPassword", v).apply()
    var autoLogin: Boolean get() = plain.getBoolean("autoLogin", false); set(v) = plain.edit().putBoolean("autoLogin", v).apply()

    // Audio
    var echoCancellation: Boolean get() = plain.getBoolean("echoCancel", true); set(v) = plain.edit().putBoolean("echoCancel", v).apply()
    var defaultSpeaker: Boolean get() = plain.getBoolean("defaultSpeaker", false); set(v) = plain.edit().putBoolean("defaultSpeaker", v).apply()

    // Notifications / privacy
    var notifyIncoming: Boolean get() = plain.getBoolean("notifyIncoming", true); set(v) = plain.edit().putBoolean("notifyIncoming", v).apply()
    var notifyMissed: Boolean get() = plain.getBoolean("notifyMissed", true); set(v) = plain.edit().putBoolean("notifyMissed", v).apply()
    /** Recording only starts after the user confirms the other party has agreed. */
    var recordingConsentPrompt: Boolean get() = plain.getBoolean("recConsent", true); set(v) = plain.edit().putBoolean("recConsent", v).apply()

    // Backup
    var dailyBackup: Boolean get() = plain.getBoolean("dailyBackup", false); set(v) = plain.edit().putBoolean("dailyBackup", v).apply()
    var lastBackupMs: Long get() = plain.getLong("lastBackup", 0L); set(v) = plain.edit().putLong("lastBackup", v).apply()
}
