package com.myvoip.app

import android.app.Application
import com.myvoip.app.sip.SipManager

class MyVoIPApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SipManager.init(this)
    }
}
