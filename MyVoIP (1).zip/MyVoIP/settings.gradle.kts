pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven {
            name = "linphone maven repository"
            url = uri("https://download.linphone.org/maven_repository/")
            content { includeGroupByRegex("org\\.linphone.*") }
        }
        maven {
            name = "linphone maven releases"
            url = uri("https://download.linphone.org/releases/maven_repository/")
            content { includeGroupByRegex("org\\.linphone.*") }
        }
    }
}

rootProject.name = "MyVoIP"
include(":app")
